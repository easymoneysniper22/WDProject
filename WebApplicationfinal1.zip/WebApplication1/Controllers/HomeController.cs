﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }


        public IActionResult Company()
        {
            var fdList = FeedbackList();
            return View(fdList);
        }



        public IActionResult EmergingTechnologies()
        {
            return View();
        }



        public IActionResult ContactAbout()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        #region FeedBack


        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Date,Username,Heading,StarRating,Feedback,Agree,Disagree,CompanyOrganisationName,canIncreaseAgree,canIncreaseDisagree")] FeedbackPost feedbackPost)
        {
            if (ModelState.IsValid)
            {
                if(User.Identity.IsAuthenticated)
                _context.Add(feedbackPost);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Company));
            }
            return View(feedbackPost);
        }
        public IActionResult Details(int? id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            //var feedbackPost = await _context.FeedbackPost
            //    .FirstOrDefaultAsync(m => m.Id == id);
            //if (feedbackPost == null)
            //{
            //    return NotFound();
            //}

            //return View(feedbackPost);
            if (id != null)
            {
                var fId = _context.FeedbackPost.FirstOrDefault(x => x.Id == id);
                return View(fId);
            }
            else
            {
                return NotFound();
            }
        }

        // GET: FeedbackPosts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var feedbackPost = await _context.FeedbackPost.FindAsync(id);
            if (feedbackPost == null)
            {
                return NotFound();
            }
            return View(feedbackPost);
        }

        // POST: FeedbackPosts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Date,Username,Heading,StarRating,Feedback,Agree,Disagree,CompanyOrganisationName,canIncreaseAgree,canIncreaseDisagree")] FeedbackPost feedbackPost)
        {
            if (id != feedbackPost.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(feedbackPost);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FeedbackPostExists(feedbackPost.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Company));
            }
            return View(feedbackPost);
        }

        // GET: FeedbackPosts/Delete/5
        //public async Task<IActionResult> Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var feedbackPost = await _context.FeedbackPost
        //        .FirstOrDefaultAsync(m => m.Id == id);
        //    if (feedbackPost == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(feedbackPost);
        //}

        public IActionResult Delete(int? id)
        {
            if (id != null)
            {
                var fId = _context.FeedbackPost.FirstOrDefault(x => x.Id == id);
                return View(fId);                
            }
            else
            {
                return NotFound();
            }
        }

        // POST: FeedbackPosts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {

            var feedbackPost = await _context.FeedbackPost.FindAsync(id);
            _context.FeedbackPost.Remove(feedbackPost);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Company));
        }

        private bool FeedbackPostExists(int id)
        {
            return _context.FeedbackPost.Any(e => e.Id == id);
        }

        [NonAction]
        public IEnumerable<FeedbackPost> FeedbackList()
        {
            var list = _context.FeedbackPost.ToList();
            return list;
        }
        #endregion
    }
}
