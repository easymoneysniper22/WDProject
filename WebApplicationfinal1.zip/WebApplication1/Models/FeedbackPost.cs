﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class FeedbackPost
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
        public string Username { get; set; }
        [Required]
        [Display(Name = "Heading")]
        public string Heading { get; set; }
        [Range(0, 5)]
        public int StarRating { get; set; }
        [Required]
        public string Feedback { get; set; }
        public int Agree { get; set; }
        public int Disagree { get; set; }
        [Required]
        public string CompanyOrganisationName { get; set; }
        public bool canIncreaseAgree { get; set; }
        public bool canIncreaseDisagree { get; set; }
    }
}
